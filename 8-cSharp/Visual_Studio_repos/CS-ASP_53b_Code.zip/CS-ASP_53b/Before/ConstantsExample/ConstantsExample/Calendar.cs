﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConstantsExample
{
    public class Calendar
    {
        //Constant Fields
    }
}