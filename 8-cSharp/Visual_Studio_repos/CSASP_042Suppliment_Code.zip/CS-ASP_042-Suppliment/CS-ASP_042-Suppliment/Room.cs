﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CS_ASP_042_Suppliment
{
    public class Room
    {
        public int RoomNumber { get; set; }
        public string Building { get; set; }
    }
}