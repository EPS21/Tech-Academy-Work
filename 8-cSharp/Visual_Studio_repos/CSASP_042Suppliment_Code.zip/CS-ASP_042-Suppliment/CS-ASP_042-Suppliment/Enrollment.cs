﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CS_ASP_042_Suppliment
{
    public class Enrollment
    {
        public Course Course { get; set; }
        public int GradePoint { get; set; }
    }
}